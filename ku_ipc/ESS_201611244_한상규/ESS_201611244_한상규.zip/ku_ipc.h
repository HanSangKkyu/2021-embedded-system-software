#define KUIPC_MAXMSG 128
#define KUIPC_MAXVOL 1024

// #define KU_IPC_CREAT _IOWR(SIMPLE_IOCTL_NUM, IOCTL_NUM1, unsigned long)
// #define KU_IPC_EXCL _IOWR(SIMPLE_IOCTL_NUM, IOCTL_NUM2, unsigned long)
// #define KU_IPC_NOWAIT _IOWR(SIMPLE_IOCTL_NUM, IOCTL_NUM3, unsigned long)
// #define KU_MSG_NOERROR _IOWR(SIMPLE_IOCTL_NUM, IOCTL_NUM4, unsigned long)


#define KU_IPC_CREAT 1
#define KU_IPC_EXCL 2
#define KU_IPC_NOWAIT 3
#define KU_MSG_NOERROR 4






